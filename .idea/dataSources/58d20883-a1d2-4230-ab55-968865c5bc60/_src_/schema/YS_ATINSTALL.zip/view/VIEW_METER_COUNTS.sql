CREATE VIEW VIEW_METER_COUNTS AS select customerid,count(*) as bs from cus_meter group by customerid
/
