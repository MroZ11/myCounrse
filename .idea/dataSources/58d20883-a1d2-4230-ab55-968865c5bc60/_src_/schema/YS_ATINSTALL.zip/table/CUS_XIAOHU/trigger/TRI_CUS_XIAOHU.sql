CREATE TRIGGER TRI_CUS_XIAOHU
BEFORE INSERT
  ON CUS_XIAOHU
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cus_xiaohu;
/
