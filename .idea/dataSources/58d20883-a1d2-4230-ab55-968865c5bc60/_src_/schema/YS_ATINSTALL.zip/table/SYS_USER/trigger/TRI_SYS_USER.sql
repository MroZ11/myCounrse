CREATE TRIGGER TRI_SYS_USER
BEFORE INSERT
  ON SYS_USER
FOR EACH ROW
  begin
select seq_public.nextval into :new.sid from dual;
end;
/
