CREATE TRIGGER TRI_SYS_UPFILES
BEFORE INSERT
  ON SYS_UPFILES
FOR EACH ROW
  begin
select seq_public.nextval into :new.sid from dual;
end;
/
