CREATE TRIGGER TRI_NET_TASK
BEFORE INSERT
  ON NET_TASK
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_net_task;
/
