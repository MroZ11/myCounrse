CREATE TRIGGER TRI_WX_USER
BEFORE INSERT
  ON WX_USER
FOR EACH ROW
  begin
select seq_public.nextval into :new.sid from dual;
end;
/
