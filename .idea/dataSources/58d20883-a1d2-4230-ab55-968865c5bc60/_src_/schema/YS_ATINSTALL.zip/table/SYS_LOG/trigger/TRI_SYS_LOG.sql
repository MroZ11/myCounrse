CREATE TRIGGER TRI_SYS_LOG
BEFORE INSERT
  ON SYS_LOG
FOR EACH ROW
  declare
  
begin
  select seq_public.nextval into :new.sid from dual;
end tri_sys_log;
/
