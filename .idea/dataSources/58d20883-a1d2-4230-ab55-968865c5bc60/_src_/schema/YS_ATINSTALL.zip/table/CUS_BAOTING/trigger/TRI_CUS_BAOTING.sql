CREATE TRIGGER TRI_CUS_BAOTING
BEFORE INSERT
  ON CUS_BAOTING
FOR EACH ROW
  declare
  -- local variables here
begin
   select seq_public.nextval into :new.sid from dual;
end tri_cus_baoting;
/
