CREATE TRIGGER TRI_SYS_OPERATOR_LOG
BEFORE INSERT
  ON SYS_OPERATOR_LOG
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_sys_operator_log;
/
