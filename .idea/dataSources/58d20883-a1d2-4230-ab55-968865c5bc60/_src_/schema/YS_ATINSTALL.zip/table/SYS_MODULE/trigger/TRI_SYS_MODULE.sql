CREATE TRIGGER TRI_SYS_MODULE
BEFORE INSERT
  ON SYS_MODULE
FOR EACH ROW
  declare
  
begin
  select seq_public.nextval into :new.sid from dual;
end tri_sys_module;
/
