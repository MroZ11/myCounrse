CREATE TRIGGER TRI_CON_METER_COLLECTORS
BEFORE INSERT
  ON CON_METER_COLLECTORS
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_con_meter_collectors;
/
