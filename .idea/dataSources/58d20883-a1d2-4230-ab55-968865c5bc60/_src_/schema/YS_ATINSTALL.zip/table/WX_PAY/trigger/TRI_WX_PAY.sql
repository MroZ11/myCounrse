CREATE TRIGGER TRI_WX_PAY
BEFORE INSERT
  ON WX_PAY
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end  tri_wx_pay;
/
