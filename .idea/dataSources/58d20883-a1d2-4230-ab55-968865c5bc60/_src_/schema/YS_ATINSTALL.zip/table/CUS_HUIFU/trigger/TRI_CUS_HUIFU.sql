CREATE TRIGGER TRI_CUS_HUIFU
BEFORE INSERT
  ON CUS_HUIFU
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cus_huifu;
/
