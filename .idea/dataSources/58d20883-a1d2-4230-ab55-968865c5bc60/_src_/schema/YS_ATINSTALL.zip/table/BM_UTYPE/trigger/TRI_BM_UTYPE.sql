CREATE TRIGGER TRI_BM_UTYPE
BEFORE INSERT
  ON BM_UTYPE
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_bm_utype;
/
