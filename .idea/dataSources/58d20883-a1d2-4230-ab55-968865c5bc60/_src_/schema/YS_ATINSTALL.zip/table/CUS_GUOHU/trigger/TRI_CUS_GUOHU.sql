CREATE TRIGGER TRI_CUS_GUOHU
BEFORE INSERT
  ON CUS_GUOHU
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cus_guohu;
/
