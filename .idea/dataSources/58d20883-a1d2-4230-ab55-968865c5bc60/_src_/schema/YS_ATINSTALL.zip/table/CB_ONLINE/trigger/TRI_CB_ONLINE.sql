CREATE TRIGGER TRI_CB_ONLINE
BEFORE INSERT
  ON CB_ONLINE
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cb_online;
/
