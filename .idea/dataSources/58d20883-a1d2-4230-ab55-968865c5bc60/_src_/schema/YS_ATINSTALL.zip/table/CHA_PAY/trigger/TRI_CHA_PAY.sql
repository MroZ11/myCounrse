CREATE TRIGGER TRI_CHA_PAY
BEFORE INSERT
  ON CHA_PAY
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cha_pay;
/
