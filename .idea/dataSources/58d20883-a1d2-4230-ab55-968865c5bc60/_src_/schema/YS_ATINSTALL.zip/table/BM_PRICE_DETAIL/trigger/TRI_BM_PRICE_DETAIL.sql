CREATE TRIGGER TRI_BM_PRICE_DETAIL
BEFORE INSERT
  ON BM_PRICE_DETAIL
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_bm_price_detail;
/
