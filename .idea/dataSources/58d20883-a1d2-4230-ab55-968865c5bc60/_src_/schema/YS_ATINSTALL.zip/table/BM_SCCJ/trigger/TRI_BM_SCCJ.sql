CREATE TRIGGER TRI_BM_SCCJ
BEFORE INSERT
  ON BM_SCCJ
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_bm_sccj;
/
