CREATE TRIGGER TRI_CB_BOOK
BEFORE INSERT
  ON CB_BOOK
FOR EACH ROW
  declare
  -- local variables here
begin
   select seq_public.nextval into :new.sid from dual;
end tri_cb_book;
/
