CREATE TRIGGER TRI_CHA_CHARGE
BEFORE INSERT
  ON CHA_CHARGE
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_cha_charge;
/
