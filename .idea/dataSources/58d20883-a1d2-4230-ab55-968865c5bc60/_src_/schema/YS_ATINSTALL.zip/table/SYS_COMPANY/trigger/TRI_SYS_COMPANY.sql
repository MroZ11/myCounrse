CREATE TRIGGER TRI_SYS_COMPANY
BEFORE INSERT
  ON SYS_COMPANY
FOR EACH ROW
  begin
select seq_public.nextval into :new.sid from dual;
end;
/
