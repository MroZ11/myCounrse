CREATE TRIGGER TRI_CUS_CUSTOMER
BEFORE INSERT
  ON CUS_CUSTOMER
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
  select seq_userid.nextval into :new.userid from dual;
end tri_cus_customer;
/
