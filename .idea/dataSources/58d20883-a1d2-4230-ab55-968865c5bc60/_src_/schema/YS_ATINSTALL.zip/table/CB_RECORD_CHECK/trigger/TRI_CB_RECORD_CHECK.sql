CREATE TRIGGER TRI_CB_RECORD_CHECK
BEFORE INSERT
  ON CB_RECORD_CHECK
FOR EACH ROW
  declare
  -- local variables here
begin
   select seq_public.nextval into :new.sid from dual;
end tri_cb_record_check;
/
