CREATE TRIGGER TRI_BM_FAJING
BEFORE INSERT
  ON BM_FAJING
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_public.nextval into :new.sid from dual;
end tri_bm_fajing;
/
