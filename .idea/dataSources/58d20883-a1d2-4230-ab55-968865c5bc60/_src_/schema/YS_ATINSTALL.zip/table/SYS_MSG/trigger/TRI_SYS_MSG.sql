CREATE TRIGGER TRI_SYS_MSG
BEFORE INSERT
  ON SYS_MSG
FOR EACH ROW
  begin
select seq_public.nextval into :new.sid from dual;
end;
/
