CREATE procedure proc_carryover(companyid in varchar2)
is
begin
  SET TRANSACTION USE ROLLBACK SEGMENT test NAME 'tran'; 
  select *  from atmeter.cb_record t  where  t.companyid= companyid;
end proc_carryover;
/
