CREATE procedure TEXT_ONE(ID in VARCHAR2,para2 out number) is
begin
    select c.endnum into para2 from cb_record c where c.id=TRIM(ID) and rownum=1;
end TEXT_ONE;
/
