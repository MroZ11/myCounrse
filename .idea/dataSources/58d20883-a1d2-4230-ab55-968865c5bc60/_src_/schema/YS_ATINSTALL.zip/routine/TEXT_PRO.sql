CREATE procedure text_pro (P_id in varchar2,charge_base out varchar2,ppt out varchar2)
as
       p1 number;
       priceid varchar(50);
      
       totalnum number;
      
       price number;
       
begin
       select count (*) into p1 from cb_record r where r.meterid =  P_id and r.cbstatus = 1 and r.checkstatus = 1;
       
       if p1 = 1  then
      
       select m.priceid into priceid  from Cus_Meter m where m.id= P_id;
              
       end if;
       
       select  p.l1_price into price from bm_price_detail p where p.priceid = priceid and p.status=1 and rownum=1 ;
     
       select nullif(nvl(r.endnum,0)-nvl(r.startnum,0),0) into totalnum  from CB_RECORD r  where r.meterid = P_id;
       
       ppt:='???';
       charge_base:=totalnum*price ;
      
       dbms_output.put_line('?????? ' || charge_base  || '!');
      
end ;


/
