CREATE procedure            Step_charging(in_bpdid in VARCHAR2,in_Actual_dosage in NUMBER,in_Cumulative_dosage in NUMBER,in_ladder_start in NUMBER,IN_CHARGE_ID IN VARCHAR2,IN_COMPANYID IN VARCHAR2,out_charge_base out number) is
/*
* in_bpdid               ???????id
* in_Actual_dosage      ????
* in_Cumulative_dosage ????
* in_ladder_start     ????
*/
v_price_l1 BM_PRICE_DETAIL.L1_PRICE%type;--??????
v_price_l2 BM_PRICE_DETAIL.L1_PRICE%type;--??????
v_price_l3 BM_PRICE_DETAIL.L1_PRICE%type;--??????
v_price_l4 BM_PRICE_DETAIL.L1_PRICE%type;--??????
v_price_l5 BM_PRICE_DETAIL.L1_PRICE%type;--??????
v_limit_l2 BM_PRICE_DETAIL.L2_PRICE%type;--??????
v_limit_l3 BM_PRICE_DETAIL.L2_PRICE%type;--??????
v_limit_l4 BM_PRICE_DETAIL.L2_PRICE%type;--??????
v_limit_l5 BM_PRICE_DETAIL.L2_PRICE%type;--??????

v_Differential_l2 BM_PRICE_DETAIL.L2_PRICE%type;--L3-L2 ?????
v_Differential_l3 BM_PRICE_DETAIL.L2_PRICE%type;--L4-L3 ?????
v_Differential_l4 BM_PRICE_DETAIL.L2_PRICE%type;--L5-L4 ?????

v_Total_l1 BM_PRICE_DETAIL.L1_PRICE%type:=0;-- ???????
v_Total_l2 BM_PRICE_DETAIL.L1_PRICE%type:=0;-- ???????
v_Total_l3 BM_PRICE_DETAIL.L1_PRICE%type:=0;-- ???????
v_Total_l4 BM_PRICE_DETAIL.L1_PRICE%type:=0;-- ???????
v_Total_l5 BM_PRICE_DETAIL.L1_PRICE%type:=0;-- ???????

/*v_Actual_l1 BM_PRICE_DETAIL.L2_Limit%type;-- ???????
v_Actual_l2 BM_PRICE_DETAIL.L2_Limit%type;-- ???????*/

v_Surplus_l1 BM_PRICE_DETAIL.L2_PRICE%type;--?????????
v_Surplus_l2 BM_PRICE_DETAIL.L2_PRICE%type;-- ????????
v_Surplus_l3 BM_PRICE_DETAIL.L2_PRICE%type;-- ????????
v_Surplus_l4 BM_PRICE_DETAIL.L2_PRICE%type;-- ????????
v_Surplus_l5 BM_PRICE_DETAIL.L2_PRICE%type;-- ????????

v_Current_price BM_PRICE_DETAIL.L1_PRICE%type;--????

begin
  select bpd.l1_price,bpd.l2_price,bpd.l2_limit,bpd.l3_price,bpd.l3_limit,
         bpd.l4_price,bpd.l4_limit,bpd.l5_price,bpd.l5_limit into v_price_l1,
         v_price_l2,v_limit_l2,v_price_l3,v_limit_l3,v_price_l4,v_limit_l4,
         v_price_l5,v_limit_l5
  from BM_PRICE_DETAIL bpd 
  where bpd.id=in_bpdid;
  v_Differential_l2:=v_limit_l3-v_limit_l2;--L3-L2 ?????
  v_Differential_l3:=v_limit_l4-v_limit_l3;--L4-L3 ?????
  v_Differential_l4:=v_limit_l5-v_limit_l4;--L5-L4 ?????
  
  if in_ladder_start=1 then--????1
   v_Surplus_l1:=v_limit_l2-in_Cumulative_dosage;--?????????
   if in_Actual_dosage<=v_Surplus_l1 then--?????? <= ????????
       v_Total_l1:=in_Actual_dosage*v_price_l1;--??????
       insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
       values(IN_CHARGE_ID,IN_COMPANYID,'1','一阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l1,v_Total_l1);
   else
       v_Total_l1:=v_Surplus_l1*v_price_l1;-- ???????
       insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
       values(IN_CHARGE_ID,IN_COMPANYID,'1','一阶梯',in_Cumulative_dosage,v_limit_l2,v_Surplus_l1,v_price_l1,v_Total_l1);
       v_Surplus_l2:=in_Actual_dosage-v_Surplus_l1;--???????????
       if v_limit_l3=0 then--?????????????
         v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
         insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
         values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l2,v_price_l2,v_Total_l2);
       elsif v_limit_l4=0 then-- ?????????????
         if v_Surplus_l2<=v_Differential_l2 then
           v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l2,v_price_l2,v_Total_l2);
         else
           v_Total_l2:=v_Differential_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,v_limit_l3,v_Differential_l2,v_price_l2,v_Total_l2);
           v_Surplus_l3:=v_Surplus_l2-v_Differential_l2;-- ?????????
           v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
         end if;
       elsif v_limit_l5=0 then
         if v_Surplus_l2<=v_Differential_l2 then
           v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l2,v_price_l2,v_Total_l2);
         else 
           v_Total_l2:=v_Differential_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,v_limit_l3,v_Differential_l2,v_price_l2,v_Total_l2);
           v_Surplus_l3:=v_Surplus_l2-v_Differential_l2;-- ?????????
           if v_Surplus_l3<=v_Differential_l3 then 
             v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
             insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
             values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
           else 
             v_Total_l3:=v_Differential_l3*v_price_l3;--???????
             insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
             values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,v_limit_l4,v_Differential_l3,v_price_l3,v_Total_l3);
             v_Surplus_l4:=v_Surplus_l3-v_Differential_l3;--?????????
             v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
             insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
             values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
           end if;
         end if;
       else
         if v_Surplus_l2<=v_Differential_l2 then
           v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l2,v_price_l2,v_Total_l2);
         else 
           v_Total_l2:=v_Differential_l2*v_price_l2;--???????
           insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
           values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',v_limit_l2,v_limit_l3,v_Differential_l2,v_price_l2,v_Total_l2);
           v_Surplus_l3:=v_Surplus_l2-v_Differential_l2;-- ?????????
           if v_Surplus_l3<=v_Differential_l3 then 
             v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
             insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
             values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
             else 
               v_Total_l3:=v_Differential_l3*v_price_l3;--???????
               insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
               values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,v_limit_l4,v_Differential_l3,v_price_l3,v_Total_l3);
               v_Surplus_l4:=v_Surplus_l3-v_Differential_l3;--?????????
               if v_Surplus_l4<=v_Differential_l4 then
                 v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
                 insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
                 values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
               else
                v_Total_l4:=v_Differential_l4*v_price_l4;--???????
                insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
                values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,v_limit_l5,v_Differential_l4,v_price_l4,v_Total_l4);
                v_Surplus_l5:=v_Surplus_l4-v_Differential_l4;--?????????
                v_Total_l5:=v_Surplus_l5*v_price_l5;--???????
                insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
                 values(IN_CHARGE_ID,IN_COMPANYID,'5','五阶梯',v_limit_l5,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l5,v_price_l5,v_Total_l5);
               end if;
           end if;
         end if;
       end if;
   end if;
  elsif in_ladder_start=2 then--?????2
    v_Surplus_l2:=v_limit_l3-in_Cumulative_dosage;-- ??????????
    if in_Actual_dosage<=v_Surplus_l2 then --????? ????? ?????????
      v_Total_l2:=in_Actual_dosage*v_price_l2;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l2,v_Total_l2);
    else--????? ?? ?????????
      if v_limit_l3=0 then--?????????????
        v_Total_l2:=in_Actual_dosage*v_price_l2;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l2,v_Total_l2);
      elsif v_limit_l4=0 then
        v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',in_Cumulative_dosage,v_limit_l3,v_Surplus_l2,v_price_l2,v_Total_l2);
        v_Surplus_l3:=in_Actual_dosage-v_Surplus_l2;--???????
        v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
      elsif v_limit_l5=0 then
        v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',in_Cumulative_dosage,v_limit_l3,v_Surplus_l2,v_price_l2,v_Total_l2);
        v_Surplus_l3:=in_Actual_dosage-v_Surplus_l2;--????????
        if v_Surplus_l3<=v_Differential_l3 then 
          v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
          insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
          values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
        else
          v_Total_l3:=v_Differential_l3*v_price_l3;--???????
          insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
          values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,v_limit_l4,v_Differential_l3,v_price_l3,v_Total_l3);
          v_Surplus_l4:=v_Surplus_l3-v_Differential_l3;--????????
          v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
          insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
          values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
        end if;
      else
        v_Total_l2:=v_Surplus_l2*v_price_l2;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'2','二阶梯',in_Cumulative_dosage,v_limit_l3,v_Surplus_l2,v_price_l2,v_Total_l2);
         v_Surplus_l3:=in_Actual_dosage-v_Surplus_l2;--????????
        if v_Surplus_l3<=v_Differential_l3 then 
          v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
          insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
          values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l3,v_price_l3,v_Total_l3);
        else
          v_Total_l3:=v_Differential_l3*v_price_l3;--???????
          insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
          values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',v_limit_l3,v_limit_l4,v_Differential_l3,v_price_l3,v_Total_l3);
          v_Surplus_l4:=v_Surplus_l3-v_Differential_l3;--????????
          if v_Surplus_l4<=v_Differential_l4 then
            v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
            insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
            values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
          else
            v_Total_l4:=v_Differential_l4*v_price_l4;--???????
            insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
            values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,v_limit_l5,v_Differential_l4,v_price_l4,v_Total_l4);
            v_Surplus_l5:=v_Surplus_l4-v_Differential_l4;--????????
            v_Total_l5:=v_Surplus_l5*v_price_l5;--???????
            insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
            values(IN_CHARGE_ID,IN_COMPANYID,'5','五阶梯',v_limit_l5,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l5,v_price_l5,v_Total_l5);
          end if;
        end if;
      end if;   
    end if;
  elsif in_ladder_start=3 then--?????3
    v_Surplus_l3:=v_limit_l4-in_Cumulative_dosage;-- ??????????
    if in_Actual_dosage<=v_Surplus_l3 then 
      v_Total_l3:=in_Actual_dosage*v_price_l3;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l3,v_Total_l3);
    elsif v_limit_l4=0 then 
      v_Total_l3:=in_Actual_dosage*v_price_l3;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l3,v_Total_l3);
    elsif v_limit_l5=0 then
      v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',in_Cumulative_dosage,v_limit_l4,v_Surplus_l3,v_price_l3,v_Total_l3);
      v_Surplus_l4:=in_Actual_dosage-v_Surplus_l3;--????????
      v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
    else
      v_Total_l3:=v_Surplus_l3*v_price_l3;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'3','三阶梯',in_Cumulative_dosage,v_limit_l4,v_Surplus_l3,v_price_l3,v_Total_l3);
      v_Surplus_l4:=in_Actual_dosage-v_Surplus_l3;--????????
      if v_Surplus_l4<=v_Differential_l4 then
        v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l4,v_price_l4,v_Total_l4);
      else
        v_Total_l4:=v_Differential_l4*v_price_l4;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',v_limit_l4,v_limit_l5,v_Differential_l4,v_price_l4,v_Total_l4);
        v_Surplus_l5:=v_Surplus_l4-v_Differential_l4;--?????????
        v_Total_l5:=v_Surplus_l5*v_price_l5;--???????
        insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
        values(IN_CHARGE_ID,IN_COMPANYID,'5','五阶梯',v_limit_l5,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l5,v_price_l5,v_Total_l5);
      end if;
    end if;
  elsif in_ladder_start=4 then--?????4
    v_Surplus_l4:=v_limit_l5-in_Cumulative_dosage;-- ??????????
    if in_Actual_dosage<=v_Surplus_l4 then
      v_Total_l4:=in_Actual_dosage*v_price_l4;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l4,v_Total_l4);
    elsif v_limit_l5=0 then
      v_Total_l4:=in_Actual_dosage*v_price_l4;--???????
      insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l4,v_Total_l4);
    else
       v_Total_l4:=v_Surplus_l4*v_price_l4;--???????
       insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
      values(IN_CHARGE_ID,IN_COMPANYID,'4','四阶梯',in_Cumulative_dosage,v_limit_l5,v_Surplus_l4,v_price_l4,v_Total_l4);
       v_Surplus_l5:=in_Actual_dosage-v_Surplus_l4;--?????????
       v_Total_l5:=v_Surplus_l5*v_price_l5;--???????
       insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
       values(IN_CHARGE_ID,IN_COMPANYID,'5','五阶梯',v_limit_l5,in_Actual_dosage+in_Cumulative_dosage,v_Surplus_l5,v_price_l5,v_Total_l5);
    end if;
  elsif in_ladder_start=5 then--?????5
    v_Total_l5:=in_Actual_dosage*v_price_l5;--??????? 
    insert into CHA_CHARGE_DETAIL (CHARGEID,COMPANYID,TYPEID,TYPE,STARTNUM,ENDNUM,NUM,PRICE,CHARGE)
    values(IN_CHARGE_ID,IN_COMPANYID,'5','五阶梯',in_Cumulative_dosage,in_Actual_dosage+in_Cumulative_dosage,in_Actual_dosage,v_price_l5,v_Total_l5);
  end if;
  v_Current_price:=v_Total_l1+v_Total_l2+v_Total_l3+v_Total_l4+v_Total_l5;
  out_charge_base:=v_Current_price;
   --dbms_output.put_line(v_Current_price);
end Step_charging;
/
