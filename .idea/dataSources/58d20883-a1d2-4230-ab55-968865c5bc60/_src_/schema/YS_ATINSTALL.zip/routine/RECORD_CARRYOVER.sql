CREATE procedure            RECORD_CARRYOVER(COMPANYID IN VARCHAR2,OUT_SYSTEM OUT VARCHAR2) is
 V_PERIOD CB_RECORD.PERIOD%TYPE;--????
 V_PROMPT VARCHAR2(1000);
 V_PROMPT_STRING VARCHAR2(1000);
 V_MONTH CB_RECORD.PERIOD%TYPE;--?
 V_YEAR CB_RECORD.PERIOD%TYPE;--?
 V_CBNUM cb_record.Endnum%TYPE;--?????
 V_JSNUM cb_record.Endnum%TYPE;--?????
 V_SHNUM cb_record.Endnum%TYPE;--?????
begin
 --未抄用户
 select count(1) into V_CBNUM
 from cb_record cr where cr.companyid ='f7507351-040e-47a6-b8e2-62d882d22668' and cr.cbstatus = 0;
 --未审核用户
 select count(1) into V_JSNUM
 from cb_record cr where cr.companyid ='f7507351-040e-47a6-b8e2-62d882d22668' and cr.jfstatus = 0;
 --未算费用户
 select count(1) into V_SHNUM
 from cb_record cr where cr.companyid ='f7507351-040e-47a6-b8e2-62d882d22668' and cr.CHECKSTATUS = 0;
 if V_CBNUM>0 
 then 
   V_PROMPT_STRING:=V_CBNUM||'??????</br>';
   V_PROMPT:=V_PROMPT||V_PROMPT_STRING;
 end if;
 if V_JSNUM>0
 then 
   V_PROMPT_STRING:=V_JSNUM||'??????</br>';
   V_PROMPT:=V_PROMPT||V_PROMPT_STRING;
 end if;
 if V_SHNUM>0
 then
   V_PROMPT_STRING:=V_SHNUM||'??????</br>';
   V_PROMPT:=V_PROMPT||V_PROMPT_STRING;
 end if;
 if V_CBNUM=0 and V_JSNUM=0 and V_SHNUM=0
 then
   UPDATE CB_RECORD C 
   SET C.STARTNUM=C.ENDNUM , C.ENDNUM=0 ,C.PLUSNUM=0,C.CBSTATUS=0,C.CBNOTES='',C.CBOPERTOR='',C.CBTIME='',C.JFSTATUS=0,C.CREATOR='',
       C.CREATETIME='',C.CHECKSTATUS=0,C.CBID='',C.PERIOD=to_char(add_months(to_date(c.period,'yyyymm'),1),'yyyymm'),C.CBORDER='' 
       WHERE 1=1;
   SELECT cr.period into V_PERIOD FROM CB_RECORD cr where rownum=1;
    V_MONTH:=SUBSTR(V_PERIOD,5,6);
    V_YEAR:=SUBSTR(V_PERIOD,0,4);
   INSERT INTO cb_period (COMPANYID,MONTH,Period,YEAR) VALUES(COMPANYID,V_MONTH,V_PERIOD,V_YEAR);
   V_PROMPT:='true';
 else 
   ROLLBACK;
 end if;
  OUT_SYSTEM:=V_PROMPT;
end RECORD_CARRYOVER;
/
