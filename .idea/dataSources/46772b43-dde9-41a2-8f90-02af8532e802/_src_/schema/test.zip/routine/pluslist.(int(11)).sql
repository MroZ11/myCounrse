CREATE PROCEDURE pluslist(IN arg INT)
  BEGIN
	SELECT id,name,age,birthday FROM `user` ;

END;
