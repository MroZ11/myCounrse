CREATE PROCEDURE plus1inout(IN arg INT, OUT res INT)
  BEGIN
	set res =arg+1;
	END;
