CREATE PROCEDURE plus1inout2(IN arg INT, OUT res INT, OUT res2 INT)
  BEGIN
	set res =arg+1;
	set res2 = arg+2;
	END;
